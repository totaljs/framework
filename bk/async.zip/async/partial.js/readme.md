![partial.js logo](http://petersirka.sk/files/92.png)

web application framework for node.js
==================================================

... in progress ...